<?php
session_start();
include('inc/connection.php');


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['paynow'])) {
    $subtotal = $_POST['subtotal'];
    $discount = $_POST['discount'];
    $total_after_discount = $_POST['total_after_discount'];
    $grandtotal = $_POST['grandtotal'];
    $products = $_POST['products'];

    $order_id_query = "SELECT orderdetail_seq.currval AS ORDER_ID FROM dual"; 
    $order_id_stmt = oci_parse($conn, $order_id_query);
    oci_execute($order_id_stmt);
    $order_id_row = oci_fetch_assoc($order_id_stmt);
    $orderid = $order_id_row['ORDER_ID'];


    $_SESSION['order_data'] = [
        'subtotal' => $subtotal,
        'discount' => $discount,
        'total_after_discount' => $total_after_discount,
        'grandtotal' => $grandtotal,
        'products' => $products,
        'orderID' => $orderID
    ];



        // PayPal sandbox credentials
        $paypalUrl = 'https://www.sandbox.paypal.com/cgi-bin/webscr';
        $paypalEmail = 'sb-o47aaa30996324@business.example.com'; 
        $returnUrl = 'http://localhost/group-project/successpayment.php'; 
        $cancelUrl = 'http://localhost/group-project/cart.php'; 
    
        // Build PayPal payment URL
        $paypalUrl .= '?cmd=_xclick';
        $paypalUrl .= '&business=' . urlencode($paypalEmail);
        $paypalUrl .= '&item_name=' . urlencode('Order Payment');
        $paypalUrl .= '&amount=' . urlencode($grandtotal);
        $paypalUrl .= '&currency_code=GBP';
        $paypalUrl .= '&return=' . urlencode($returnUrl);
        $paypalUrl .= '&cancel_return=' . urlencode($cancelUrl);


        header('Location: ' . $paypalUrl);
        exit;
}
else {
    echo "<script>alert('Invalid request');window.location.href = 'cart.php'</script>";
}
?>