<?php 
session_start(); 
require "inc/connection.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require '../phpmailer/src/Exception.php';
require '../phpmailer/src/PHPMailer.php';
require '../phpmailer/src/SMTP.php';

$errors = array();

function sendEmail($to, $subject, $message) {
    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();                                            // Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                       // Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
        $mail->Username   = 'dhakalroce@gmail.com';                // SMTP username
        $mail->Password   = 'jglf cqll ghgg ihgf';                  // SMTP password
        $mail->SMTPSecure = 'tls';                                  // Enable TLS encryption
        $mail->Port       = 587;                                    // TCP port to connect to

        // Recipients
        $mail->setFrom('dhakalroce@gmail.com', 'ADMIN');
        $mail->addAddress($to);                                     // Add a recipient

        // Content
        $mail->isHTML(true);                                        // Set email format to HTML
        $mail->Subject = $subject;
        $mail->Body    = $message;
        $mail->AltBody = strip_tags($message);                      // Plain text alternative

        $mail->send();
        return true;
    } catch (Exception $e) {
        // Handle exceptions
        error_log("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");
        return false;
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Email</title>
    <?php include('inc/link.php'); ?>
</head>
<body>
<div class="main-wrapper">
    <div class="header-container fixed-top">
        <!-- top header start -->
        <?php include('inc/header.php'); ?>
        <!-- top header end -->
    </div>

    <!-- side bar start -->
    <?php include('inc/sidebar.php'); ?>
    <!-- side bar end -->
    <div class="content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h2>Send Email</h2>
                    <form method="post">
                        <div class="mb-3">
                            <label for="to" class="form-label">Recipient Email</label>
                            <input type="email" class="form-control" id="to" name="to" required>
                        </div>
                        <div class="mb-3">
                            <label for="subject" class="form-label">Subject</label>
                            <input type="text" class="form-control" id="subject" name="subject" required>
                        </div>
                        <div class="mb-3">
                            <label for="message" class="form-label">Message</label>
                            <textarea class="form-control" id="message" name="message" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Send</button>
                    </form>
                    <?php
                    if ($_SERVER["REQUEST_METHOD"] === "POST") {
                        $to = $_POST["to"];
                        $subject = $_POST["subject"];
                        $message = $_POST["message"];

                        $mail_sent = sendEmail($to, $subject, $message);
                        if($mail_sent) {
                            echo "<div class='alert alert-success' role='alert'>Mail sent successfully to $to</div>";
                        } else {
                            echo "<div class='alert alert-danger' role='alert'>Mail sending failed</div>";
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include('inc/footer.php'); ?>
</body>
</html>
