<?php
$conn = oci_connect('roshna', 'roce4801', '//localhost/xe');
if (!$conn) {
   $m = oci_error();
   echo $m['message'], "\n";
   exit;
} else {
   // echo "Connected to Oracle!"; 
}

// Return the connection object
return $conn;
?>