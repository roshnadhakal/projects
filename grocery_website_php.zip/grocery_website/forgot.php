<?php
session_start();
ob_start();
require "inc/connection.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

$errors = array();

if (isset($_POST['send_otp'])) {
    $email = $_POST['email'];
    $email = htmlspecialchars(strip_tags($email));

    // Check if email exists
    $email_check = oci_parse($conn, "SELECT * FROM customer WHERE email = :email");
    oci_bind_by_name($email_check, ":email", $email);
    oci_execute($email_check);

    if (oci_fetch($email_check) > 0) {
        // Generate OTP
        $otp = rand(100000, 999999);

        // Store OTP in the database
        $update_otp = oci_parse($conn, "UPDATE customer SET otp = :otp WHERE email = :email");
        oci_bind_by_name($update_otp, ":otp", $otp);
        oci_bind_by_name($update_otp, ":email", $email);
        oci_execute($update_otp);

        // Send OTP to user's email
        if (sendOTP($email, $otp)) {
            $_SESSION['otp_email'] = $email;
            header('Location: reset_password.php'); // Redirect to reset_password.php
            exit();
        } else {
            $errors['mail-error'] = "Failed to send OTP email.";
        }
    } else {
        $errors['email'] = "No account found with this email.";
    }
}

function sendOTP($email, $otp) {
    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();                                            // Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                       // Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
        $mail->Username   = 'dhakalroce@gmail.com';                // SMTP username
        $mail->Password   = 'jglf cqll ghgg ihgf';                        // SMTP password
        $mail->SMTPSecure = 'tls';            // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
        $mail->Port       = 587;                                    // TCP port to connect to, use 587 for `PHPMailer::ENCRYPTION_STARTTLS`

        // Recipients
        $mail->setFrom('dhakalroce@gmail.com', 'ADMIN');
        $mail->addAddress($email);                                  // Add a recipient

        // Content
        $mail->isHTML(true);                                        // Set email format to HTML
        $mail->Subject = 'OTP Verification';
        $mail->Body    = "Your OTP for verification is: $otp";
        $mail->AltBody = "Your OTP for verification is: $otp";       // Plain text alternative

        $mail->send();
        return true;
    } catch (Exception $e) {
        // Handle exceptions
        error_log("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");
        return false;
    }
}

ob_end_flush();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Forgot Password</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Bootstrap Ecommerce" name="keywords">
    <?php include('inc/link.php'); ?>
</head>

<body>
    <?php include('inc/header.php'); ?>
    <div class="login">
        <div class="container">
            <div class="section-header">
                <h3>Forgot Password</h3>
                <p>Please enter your email to receive a password reset OTP.</p>
            </div>
            <form action="" method="post">
                <div class="row">
                    <div class="col-md-12">
                        <label>Email</label>
                        <input name="email" class="form-control" type="email" placeholder="Enter your email" required>
                    </div>
                    <div class="col-md-12">
                        <button type="submit" name="send_otp" class="btn shadow-none btn-lg mb-3">Send OTP</button>
                    </div>
                </div>
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <?php foreach ($errors as $error): ?>
                            <p><?php echo $error; ?></p>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/slick/slick.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>
</html>
